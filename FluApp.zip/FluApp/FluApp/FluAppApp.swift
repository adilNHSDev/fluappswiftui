//
//  FluAppApp.swift
//  FluApp
//
//  Created by ICTDevelopment on 14/03/2023.
//

import SwiftUI

@main
struct FluAppApp: App {
    
    init(){
        fetchGender()
        fetchEthnicity()
        fetchStaffGroup()
        fetchEmployers()
        fetchConsent()
        fetchVaccines()
        fetchEmployees()
        fetchEmployeeData()
    }
    
    var body: some Scene {
        
        
        
        WindowGroup {
            
            ContentViewLogin()
            //VaccineInfo()
        }
    }
    

}
