//
//  ContentView.swift
//  FluApp
//
//  Created by ICTDevelopment on 14/03/2023.
//

import SwiftUI
import Combine

struct EmployeeData: Codable {
     var employeeID: String
     var smartCardNum: String
     var NHSnum: String
     var birthDate: Date
     var startDate: Date
     var firstname : String
     var lastname: String
     var gender: String
     var ethnicity: String
     var employer: String
     var staffGroup: String
     var jobRole: String
     var ward: String
     var postcode: String
     var carer: String
     var frontLine: String
     var administeredonbody: String
     var vaccineadministered: String
     var adversereaction: String
     var vaccinedate: Date
     var vaccinatorfname: String
     var vaccinatorlname: String
     var vaccinatorjob: String
     var vaccinevenue: String
}

class api {
    static var gender: [String] = ["Unselected"]
    static var employers: [String] = ["UHCW"]
    static var ethnicity: [String] = ["Unselected"]
    static var staffgroup: [String] = ["Unselected"]
    static var vaccines: [String] = ["Unselected"]
    static var consent: [String] = ["consent text placeholder"]
    static var employees: [[String]] = [["name", "id"]]
    static var employeeData: EmployeeData = EmployeeData(employeeID: "", smartCardNum: "", NHSnum: "", birthDate: Date(), startDate: Date(), firstname: "", lastname: "", gender: "Unselected", ethnicity: "Unselected", employer: "", staffGroup: "Unselected", jobRole: "", ward: "", postcode: "", carer: "Unselected", frontLine: "Unselected", administeredonbody: "Unselected", vaccineadministered: "Unselected", adversereaction: "", vaccinedate: Date(), vaccinatorfname: " " , vaccinatorlname: "", vaccinatorjob: "", vaccinevenue: "")
}

class data {
    static var employeeID: String = ""
    static var smartCardNum: String = ""
    static var NHSnum: String = ""
    static var birthDate: Date = Date()
    static var startDate: Date = Date()
    static var firstname : String = ""
    static var lastname: String = ""
    static var gender: String = "Male"
    static var ethnicity: String = ""
    static var employer: String = ""
    static var staffGroup: String = ""
    static var jobRole: String = ""
    static var ward: String = ""
    static var postcode: String = ""
    static var carer: String = ""
    static var frontLine: String = ""
    static var administeredonbody: String = ""
    static var vaccineadministered: String = ""
    static var adversereaction: String = ""
    static var vaccinedate: Date = Date()
    static var vaccinatorfname: String = ""
    static var vaccinatorlname: String = ""
    static var vaccinatorjob: String = ""
    static var vaccinevenue: String = ""
    

}

func fetchGender() {
    // Make API call to fetch button titles
    // Here's an example using URLSession:
    //self.buttonTitles = ["x","c"]
    
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/gender") else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let genders = try? JSONDecoder().decode([String].self, from: data) {
                DispatchQueue.main.async {
                    api.gender = api.gender + genders
                }
            }
        }
    }.resume()
}

func fetchEthnicity() {
    // Make API call to fetch button titles
    // Here's an example using URLSession:
    //self.buttonTitles = ["x","c"]
    
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/ethnicity") else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let ethnicities = try? JSONDecoder().decode([String].self, from: data) {
                DispatchQueue.main.async {
                    api.ethnicity = api.ethnicity + ethnicities
                }
            }
        }
    }.resume()
}

func fetchStaffGroup() {
    // Make API call to fetch button titles
    // Here's an example using URLSession:
    //self.buttonTitles = ["x","c"]
    
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/staff_group") else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let staffgroups = try? JSONDecoder().decode([String].self, from: data) {
                DispatchQueue.main.async {
                    api.staffgroup = api.staffgroup + staffgroups
                }
            }
        }
    }.resume()
}

func fetchEmployers() {
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/employers") else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let employers = try? JSONDecoder().decode([String].self, from: data) {
                DispatchQueue.main.async {
                    api.employers = employers
                }
            }
        }
    }.resume()
}


func fetchVaccines() {
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/vaccines") else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let vaccines = try? JSONDecoder().decode([String].self, from: data) {
                DispatchQueue.main.async {
                    api.vaccines = api.vaccines + vaccines
                    print(api.vaccines)
                }
            }
        }
    }.resume()
}

func fetchConsent() {
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/consent") else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let consent = try? JSONDecoder().decode([String].self, from: data) {
                DispatchQueue.main.async {
                    api.consent = consent
                }
            }
        }
    }.resume()
}

func fetchEmployees() {
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/employees") else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let employees = try? JSONDecoder().decode([[String]].self, from: data) {
                DispatchQueue.main.async {
                    api.employees = employees
                    print(employees)
                }
            }
        }
    
    }.resume()
}

func fetchEmployeesSearch(search: String) {
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/employees"+search) else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let employees = try? JSONDecoder().decode([[String]].self, from: data) {
                DispatchQueue.main.async {
                    api.employees = employees
                    print(employees)
                }
            }
        }
    
    }.resume()
}

func fetchEmployeeData() {
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/employeeData") else {
        return
    }
    
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            if let employeedata = try? JSONDecoder().decode(EmployeeData.self, from: data) {
                DispatchQueue.main.async {
                    api.employeeData = employeedata
                }
            }
        }
    
    }.resume()
}


func postData() {
    guard let url = URL(string: "https://1de61d0d-4eec-4160-90d7-a196915ea8f6.mock.pstmn.io/post_data") else {
        print("Invalid URL")
        return
    }
    
    let body = ["employeeID" : data.employeeID,
                "smartCardNum": data.smartCardNum,
                "NHSnum": data.NHSnum,
                //"birthDate": String(data.birthDate),
                //"startDate": String(data.startDate),
                "firstname": data.firstname,
                "lastname": data.lastname,
                "gender": data.gender,
                "ethnicity": data.ethnicity,
                "employer": data.employer,
                "staffGroup": data.staffGroup,
                "jobRole": data.jobRole,
                "ward": data.ward,
                "postcode": data.postcode,
                "carer": data.carer,
                "frontLine": data.frontLine,
                "administeredonbody": data.administeredonbody,
                "vaccineadministered": data.vaccineadministered,
                "adversereaction": data.adversereaction,
                //"vaccinedate": data.vaccinedate,
                "vaccinatorfname": data.vaccinatorfname,
                "vaccinatorlname": data.vaccinatorlname,
                "vaccinatorjob": data.vaccinatorjob,
                "vaccinevenue": data.vaccinevenue]
    
    let jsonData = try? JSONSerialization.data(withJSONObject: body)
    
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.httpBody = jsonData
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data else {
            print("No data in response: \(error?.localizedDescription ?? "Unknown error")")
            return
        }
        
        /*if let decodedResponse = try? JSONDecoder().decode(YourDecodableType.self, from: data) {
            DispatchQueue.main.async {
                self.result = decodedResponse.message
            }
        } else {
            let responseString = String(data: data, encoding: .utf8) ?? ""
            print("Invalid response: \(responseString)")
        }*/
    }.resume()
}

struct ContentViewLogin: View {
    @State private var username = ""
    @State private var password = ""
    @State private var isActive: Bool = false
    @State private var showingAlert = false

    init(){
        
        //fetchConsent()
    }
    
    var body: some View {
        
        NavigationStack{
            VStack {
                TextField("Username", text: $username)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(5.0)
                    .padding(.bottom, 20)
                
                SecureField("Password", text: $password)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(5.0)
                    .padding(.bottom, 20)
                
                Button(action: {
                    if self.username == "" {
                        //self.showingAlert = true
                        isActive = true
                        
                    } else {
                        // wrong
                    }
                }) {
                    Text("Login")
                        .fontWeight(.bold)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10.0)
                }
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("Error"), message: Text("Username and password are required"), dismissButton: .default(Text("OK")))
                }
            }
            NavigationLink(
                destination: ButtonListView(),
                isActive: $isActive,
                label: {
                    //Text("Go to Detail View")
                })
            .padding()
            
        }
        .navigationBarTitle("Login")

    }

}


struct EmployeeInfo: View {
    @State private var flujab = "Unselected"
    @State private var pregnant = "Unselected"
    @State private var flujabBlank = false
    @State private var pregnantBlank = false
    @State private var showingAlert = false
    @State private var showPregnant = true
    @State private var isActive = false
    @State private var isActive1 = false
    
    let flujabs = ["Unselected", "True", "False"]
    let pregnants = ["Unselected", "True", "False"]
    
    init(){
        /*print("gender: "+String(data.gender))
        if String(data.gender) == "Male" {
            self.showPregnant = false
            pregnant = "False"
            print("stat true")
            print(self.showPregnant)
        }*/
    }
    
    var body: some View {
        Form{
            Section(header: Text("Extra Details")) {
                Picker(selection: $flujab, label: Text("Declined flujab?")) {
                    ForEach(flujabs, id: \.self) { flujab in
                        Text(flujab)
                    }
                }
                
                if flujabBlank {
                    Text("Please fill field")
                        .foregroundColor(.red)
                }
                
                if String(data.gender) != "Male" {
                    Picker(selection: $pregnant, label: Text("Pregnant?")) {
                        ForEach(pregnants, id: \.self) { pregnant in
                            Text(pregnant)
                        }
                    }
                    
                    if pregnantBlank {
                        Text("Please fill field")
                            .foregroundColor(.red)
                    }
                }
            }
            
            Button(action: {
                if String(self.flujab) == "Unselected" || (String(self.pregnant) == "Unselected" && String(data.gender) != "Male"){
                    if String(self.flujab) == "Unselected" { self.flujabBlank = true }
                    if String(self.pregnant) == "Unselected" { self.pregnantBlank = true }

                } else {
                    if String(self.flujab) == "True"{
                        self.isActive1 = true  // sends to upload
                    }else{
                        self.isActive = true  // sends to vaccination details
                    }
                }
            }) {
                Text("Submit")
                    .fontWeight(.bold)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .cornerRadius(10.0)
            }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Unfilled Fields"), message: Text("Please check and fill all fields"), dismissButton: .default(Text("OK")))
            }
            

        }
        
        NavigationLink(
            destination: VaccineDetails(),
            isActive: $isActive,
            label: {
                //Text("Go to Detail View")
            })
        
        NavigationLink(
            destination: Upload(),
            isActive: $isActive1,
            label: {
                //Text("Go to Detail View")
            })

    }
    
}

struct UserForm: View {
    @State private var firstName = api.employeeData.firstname
    @State private var lastName = api.employeeData.lastname
    @State private var gender = api.employeeData.gender
    @State private var birthDate = Date()
    @State private var startDate = Date()
    @State private var employeeID = api.employeeData.employeeID
    @State private var smartCardNumber = api.employeeData.smartCardNum
    @State private var nhsNumber = api.employeeData.NHSnum
    @State private var showingAlert = false
    @State private var showingAlert1 = false
    @State private var jobRole = api.employeeData.jobRole
    @State private var ward = api.employeeData.ward
    @State var postcode = api.employeeData.postcode
    @State private var isValid = false
    @State private var showErrorPCode = false
    @State private var carer = api.employeeData.carer
    @State private var frontLine = api.employeeData.frontLine
    @State private var employeeidShort = false
    @State private var smartcardShort = false
    @State private var nhsnumShort = false
    @State private var fnameShort = false
    @State private var lnameShort = false
    @State private var fnameBlank = false
    @State private var lnameBlank = false
    @State private var genderBlank = false
    @State private var ethnicityBlank = false
    @State private var staffgroupBlank = false
    @State private var frontLineBlank = false
    @State private var carerBlank = false
    @State private var jobroleShort = false
    @State private var jobroleBlank = false
    @State private var wardShort = false
    @State private var wardBlank = false
    @State private var ethnicity = api.employeeData.ethnicity
    @State private var staffgroup = api.employeeData.staffGroup
    @State private var isActive = false
    
    
    private let postcodeRegex = "^[A-Za-z]{1,2}[0-9Rr][0-9A-Za-z]?\\s?[0-9][A-Za-z]{2}$"
    
    let ethnicities = api.ethnicity
    let staffgroups = api.staffgroup
    let genders = api.gender //["Male", "Female", "Other"]
    let carers = ["Unselected", "Yes", "No", "Declined To Answer", "Not Known"]
    let frontlines = ["Unselected", "True", "False"]
    
    var minimumDate: Date {
        let calendar = Calendar.current
        let currentDate = Date()
        let eighteenYearsAgo = calendar.date(byAdding: .year, value: -18, to: currentDate)!
        return calendar.date(byAdding: .day, value: 1, to: eighteenYearsAgo)!
    }
    
    var maximumDate: Date {
        let calendar = Calendar.current
        let currentDate = Date()
        let today = calendar.date(byAdding: .year, value: 0, to: currentDate)!
        return calendar.date(byAdding: .day, value: 0, to: today)!
    }
    
    init(){

    }
    
    var body: some View {
        
            Form {
                Section(header: Text("Identification")) {
                    TextField("Employee ID Number", text: $employeeID)
                        .keyboardType(.numberPad)
                        .onReceive(Just(employeeID)) { newValue in
                            let filtered = newValue.filter { "0123456789".contains($0) }
                            if filtered != newValue {
                                self.employeeID = filtered
                                //self.showingAlert = true
                            } else if newValue.count > 8 {
                                self.employeeID = String(newValue.prefix(8))
                                //self.showingAlert = true
                            }else if newValue.count > 8 && newValue.count > 0 {
                                
                            }
                        }
                    
                    if employeeidShort {
                        Text("Field requires 8 characters")
                            .foregroundColor(.red)
                    }
                    
                    TextField("Smart Card Number", text: $smartCardNumber)
                        .keyboardType(.numberPad)
                        .onReceive(Just(smartCardNumber)) { newValue in
                            let filtered = newValue.filter { "0123456789".contains($0) }
                            if filtered != newValue {
                                self.smartCardNumber = filtered
                                //self.showingAlert = true
                            } else if newValue.count > 12 {
                                self.smartCardNumber = String(newValue.prefix(12))
                                //self.showingAlert = true
                            }
                        }
                    
                    if smartcardShort {
                        Text("Field requires 12 characters")
                            .foregroundColor(.red)
                    }
                    
                    TextField("NHS Number", text: $nhsNumber)
                        .keyboardType(.numberPad)
                        .onReceive(Just(nhsNumber)) { newValue in
                            let filtered = newValue.filter { "0123456789".contains($0) }
                            if filtered != newValue {
                                self.nhsNumber = filtered
                                //self.showingAlert = true
                            } else if newValue.count > 10 {
                                self.nhsNumber = String(newValue.prefix(10))
                                //self.showingAlert = true
                            }
                        }
                    
                    if nhsnumShort {
                        Text("Field requires 10 characters")
                            .foregroundColor(.red)
                    }
                }
                
                
                    DatePicker("Birth Date", selection: $birthDate, in: ...minimumDate, displayedComponents: .date)
                
                
                
                    DatePicker("Start Date", selection: $startDate, in: ...maximumDate, displayedComponents: .date)
                
                
                Section(header: Text("Name")) {
                    TextField("First Name", text: $firstName)
                        .autocapitalization(.words)
                        .textContentType(.givenName)
                        .disableAutocorrection(true)
                        .onReceive(Just(firstName)) { newValue in
                            let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                            if filtered != newValue {
                                self.firstName = filtered
                                //self.showingAlert = true
                            } else if newValue.count < 3 && newValue.count != 0 {
                                self.fnameShort = true
                                //self.employeeID = String(newValue.prefix(8))
                                //self.showingAlert = true
                            } else if newValue.count >= 3 {
                                self.fnameShort = false
                            }
                        }
                    
                    if fnameShort {
                        Text("Name too short")
                            .foregroundColor(.red)
                    }
                    
                    if fnameBlank {
                        Text("Field blank")
                            .foregroundColor(.red)
                    }
                    
                    TextField("Last Name", text: $lastName)
                        .autocapitalization(.words)
                        .textContentType(.familyName)
                        .disableAutocorrection(true)
                        .onReceive(Just(lastName)) { newValue in
                            let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                            if filtered != newValue {
                                self.lastName = filtered
                                //self.showingAlert = true
                            } else if newValue.count < 3 && newValue.count != 0 {
                                self.lnameShort = true
                                //self.employeeID = String(newValue.prefix(8))
                                //self.showingAlert = true
                            } else if newValue.count >= 3 {
                                self.lnameShort = false
                            }
                        }
                    
                    if lnameShort {
                        Text("Name too short")
                            .foregroundColor(.red)
                    }
                    
                    if lnameBlank {
                        Text("Field blank")
                            .foregroundColor(.red)
                    }
                }
                
                Section(header: Text("Personal Details")) {
                    Picker(selection: $gender, label: Text("Gender")) {
                        ForEach(genders, id: \.self) { gender in
                            Text(gender)
                        }
                    }
                    
                    if genderBlank {
                        Text("Please fill field")
                            .foregroundColor(.red)
                    }

                    Picker(selection: $ethnicity, label: Text("Ethnicity")) {
                        ForEach(ethnicities, id: \.self) { ethnicity in
                            Text(ethnicity)
                        }
                    }
                    
                    if ethnicityBlank {
                        Text("Please fill field")
                            .foregroundColor(.red)
                    }
                    
                    Picker(selection: $staffgroup, label: Text("Staff Group")) {
                        ForEach(staffgroups, id: \.self) { staffgroup in
                            Text(staffgroup)
                        }
                    }
                    
                    if staffgroupBlank {
                        Text("Please fill field")
                            .foregroundColor(.red)
                    }
                }
                
                
                Section(header: Text("Job Details")) {
                    TextField("Job Title/Role", text: $jobRole)
                        .autocapitalization(.words)
                        .textContentType(.givenName)
                        .disableAutocorrection(true)
                        .onReceive(Just(jobRole)) { newValue in
                            self.jobroleBlank = false
                            let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                            if filtered != newValue {
                                self.jobRole = filtered
                                //self.showingAlert = true
                            } else if newValue.count > 100 {
                                self.jobRole = String(newValue.prefix(100))
                            } else if newValue.count < 3 && newValue.count != 0 {
                                self.jobroleShort = true
                            } else if newValue.count >= 3 {
                                self.jobroleShort = false
                            }
                        }
                    
                    if jobroleShort {
                        Text("Answer too short")
                            .foregroundColor(.red)
                    }
                    
                    if jobroleBlank {
                        Text("Field blank")
                            .foregroundColor(.red)
                    }
                    
                    TextField("Ward", text: $ward)
                        .autocapitalization(.words)
                        .textContentType(.familyName)
                        .disableAutocorrection(true)
                        .onReceive(Just(ward)) { newValue in
                            self.wardBlank = false
                            let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                            if filtered != newValue {
                                self.ward = filtered
                                //self.showingAlert = true
                            } else if newValue.count > 50 {
                                self.ward = String(newValue.prefix(50))
                            } else if newValue.count < 3 && newValue.count != 0 {
                                self.wardShort = true
                            } else if newValue.count >= 3 {
                                self.wardShort = false
                            }
                        }
                    
                    if wardShort {
                        Text("Answer too short")
                            .foregroundColor(.red)
                    }
                    
                    if wardBlank {
                        Text("Field blank")
                            .foregroundColor(.red)
                    }
                }
                
                Section {
                    TextField("Postcode", text: $postcode)
                        .textContentType(.postalCode)
                        .onChange(of: postcode) { newValue in
                            let isValidPostcode = NSPredicate(format:"SELF MATCHES %@", postcodeRegex).evaluate(with: newValue)
                            isValid = isValidPostcode
                        }
                    
                    if !isValid && !postcode.isEmpty {
                        Text("Invalid Postcode")
                            .foregroundColor(.red)
                    }
                }
                Section(header: Text("Personal Details")) {
                    Picker(selection: $carer, label: Text("Carer")) {
                        ForEach(carers, id: \.self) { carer in
                            Text(carer)
                        }
                    }
                    
                    if carerBlank {
                        Text("Please fill field")
                            .foregroundColor(.red)
                    }

                    Picker(selection: $frontLine, label: Text("Front Line Staff")) {
                        ForEach(frontlines, id: \.self) { fline in
                            Text(fline)
                        }
                    }
                    
                    if frontLineBlank {
                        Text("Please fill field")
                            .foregroundColor(.red)
                    }
                }
                
                Section {
                    Button(action: submitForm) {
                        Text("Submit")
                    }
                }
                
                
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("Unfilled Fields"), message: Text("Please check and fill all fields"), dismissButton: .default(Text("OK")))
                }
                

            }
        
        NavigationLink(
            destination: EmployeeInfo(),
            isActive: $isActive,
            label: {
                //Text("Go to Detail View")
            })
            
    }
    
    func submitForm() {
        if String(gender) == "Unselected" || String(carer) == "Unselected" || String(frontLine) == "Unselected" || String(ethnicity) == "Unselected" || String(staffgroup) == "Unselected" {
            self.showingAlert = true
            if String(gender) == "Unselected" {self.genderBlank = true}
            if String(carer) == "Unselected" {self.carerBlank = true}
            if String(frontLine) == "Unselected" {self.frontLineBlank = true}
            if String(ethnicity) == "Unselected" {self.ethnicityBlank = true}
            if String(staffgroup) == "Unselected" {self.staffgroupBlank = true}
        }
        
        if jobRole.isEmpty {
            self.jobroleBlank = true
            self.showingAlert = true
        }else if ward.isEmpty {
            self.wardBlank = true
            self.showingAlert = true
        }else if employeeID.isEmpty {
            //self.employeeidBlank = true
            self.showingAlert = true
        }else if smartCardNumber.isEmpty {
            //self.smartcardBlank = true
            self.showingAlert = true
        }else if nhsNumber.isEmpty {
            //self.nhsnumBlank = true
            self.showingAlert = true
        }else if firstName.isEmpty {
            self.fnameBlank = true
            self.showingAlert = true
        }else if lastName.isEmpty {
            self.lnameBlank = true
            self.showingAlert = true
        }else if postcode.isEmpty {
            //self.postcodeBlank = true
            self.showingAlert = true
        }
        
        if self.showingAlert {
            return
        }
        
        data.employeeID = employeeID
        data.smartCardNum = smartCardNumber
        data.NHSnum = nhsNumber
        data.startDate = startDate
        data.birthDate = birthDate
        data.firstname = firstName
        data.lastname = lastName
        data.gender = gender
        data.ethnicity = ethnicity
        data.staffGroup = staffgroup
        data.jobRole = jobRole
        data.ward = ward
        data.postcode = postcode
        data.carer = carer
        data.frontLine = frontLine
        
        print("submit")
        
        // next page
        self.isActive = true

    }

}



struct MyButton: View {
    let title: String
    @Binding var isActive: Bool
    
    var body: some View {
        Button(action: {
            print(self.title)
            data.employer = self.title
            isActive = true
            // Do something when button is tapped
        }) {
            Text(title)
                .padding()
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(40)
        }
    }
}

struct ButtonListView: View {
    @State private var buttonTitles: [String] = []
    @State private var isActive: Bool = false
    
    init(){
        print(api.employees)
    }
    
    
    var body: some View {
        
        VStack {
            ForEach(buttonTitles, id: \.self) { title in
                MyButton(title: title, isActive: $isActive)
            }
        }
        .onAppear {
            fetchButtonTitles()
            print(api.employees)
        }
        NavigationLink(
            destination: ManualorSearch(),
            isActive: $isActive,
            label: {
                //Text("Go to Detail View")
            })
    }
    
    /*func setvar(){
        isActive = true
        print("move")
    }*/
    
    func fetchButtonTitles() {
        self.buttonTitles = api.employers
    }
}

struct VaccineDetails: View {
    @State private var vaccineElsewhere = "Unselected"
    @State private var venue = ""
    @State private var vaccBlank = false
    @State private var venueBlank = false
    @State private var showElsewhere = true
    @State private var isActive = false
    @State private var isActive1 = false
    @State private var vaccDate = Date()
    @State private var venueShort = false
    @State private var showingAlert = false
    
    
    let vacc = ["Unselected", "Yes", "No"]
    
    var maximumDate: Date {
        let calendar = Calendar.current
        let currentDate = Date()
        let today = calendar.date(byAdding: .year, value: 0, to: currentDate)!
        return calendar.date(byAdding: .day, value: 0, to: today)!
    }
    
    var body: some View {
        Form{
            Section(header: Text("Vaccination Details")) {
                Picker(selection: $vaccineElsewhere, label: Text("Have you had the vaccine elsewhere?")) {
                    ForEach(vacc, id: \.self) { vaccineElsewhere in
                        Text(vaccineElsewhere)
                    }
                }
                
                if vaccBlank {
                    Text("Please fill field")
                        .foregroundColor(.red)
                }
                
                if vaccineElsewhere == "Yes" {
                    TextField("Venue", text: $venue)
                        .onReceive(Just(venue)) { newValue in
                            self.venueBlank = false
                            let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                            if filtered != newValue {
                                self.venue = filtered
                            } else if newValue.count > 50 {
                                self.venue = String(newValue.prefix(50))
                            } else if newValue.count < 3 && newValue.count != 0 {
                                self.venueShort = true
                            } else if newValue.count >= 3 {
                                self.venueShort = false
                            }
                        }
                    
                    if venueShort {
                        Text("Answer too short")
                            .foregroundColor(.red)
                    }
                    
                    if venueBlank {
                        Text("Please fill field")
                            .foregroundColor(.red)
                    }
                    
                    DatePicker("Vaccine Date", selection: $vaccDate, in: ...maximumDate, displayedComponents: .date)
                    
                }

                
            }
            
            Button(action: {
                if String(self.vaccineElsewhere) == "Unselected" {
                    if String(self.vaccineElsewhere) == "Unselected" { self.vaccBlank = true }
                    self.showingAlert = true
                }else if vaccineElsewhere == "Yes" && ( self.venue.isEmpty || self.venueShort) {
                    self.venueBlank = true
                    self.showingAlert = true
                }
                
                if self.showingAlert { return }
                
                if vaccineElsewhere == "Yes" {
                    data.vaccinevenue = self.venue
                    data.vaccinedate = self.vaccDate
                    self.isActive = true
                }else {
                    self.isActive1 = true
                }
            }) {
                Text("Submit")
                    .fontWeight(.bold)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .cornerRadius(10.0)
            }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Unfilled Fields"), message: Text("Please check and fill all fields"), dismissButton: .default(Text("OK")))
            }
            

        }
        
        NavigationLink(
            destination: Upload(),
            isActive: $isActive,
            label: {
                //Text("Go to Detail View")
            })
        NavigationLink(
            destination: VaccineInfo(),
            isActive: $isActive1,
            label: {
                //Text("Go to Detail View")
            })

    }
    
}

struct VaccineInfo: View {
    @State private var administered = "Unselected"
    @State private var vaccine = "Unselected"
    @State private var reactionDetails = ""
    @State private var vaccinatorFirstname = ""
    @State private var vaccinatorSurname = ""
    @State private var fnameShort = false
    @State private var fnameBlank = false
    @State private var lnameShort = false
    @State private var lnameBlank = false
    @State private var vaccinatorjobrole = ""
    @State private var jobroleShort = false
    @State private var jobroleBlank = false
    @State private var venue = ""
    @State private var doConsent = false
    @State private var isChecked = false
    @State private var showingAlert = false
    @State private var consented = true
    @State private var isActive = false
    @State private var administeredBlank = false
    @State private var vaccineBlank = false
    @State private var vaccDate = Date()
    
    let administereds = ["Unselected", "Left Upper Arm", "Right Upper Arm"]
    
    let vaccines = api.vaccines // ["Unselected", "Left Arm", "Right Arm"]///-------
    
    var maximumDate: Date {
        let calendar = Calendar.current
        let currentDate = Date()
        let today = calendar.date(byAdding: .year, value: 0, to: currentDate)!
        return calendar.date(byAdding: .day, value: 0, to: today)!
    }
    
    var body: some View {
        Form{
            Section(header: Text("Vaccination Details")) {
                
                Text(api.consent[0])
                
                Toggle(isOn: $isChecked) {
                    Text("I Consent")
                }
                .toggleStyle(iOSCheckboxToggleStyle())
                
                if !consented {
                    Text("You must consent to continue")
                        .foregroundColor(.red)
                }
                
            }
            
            if isChecked == true {
                Section(header: Text("Vaccination Details")) {
                    Picker(selection: $administered, label: Text("Where was it administered")) {
                        ForEach(administereds, id: \.self) { administered in
                            Text(administered)
                        }
                    }
                    
                    if administeredBlank {
                        Text("Field blank")
                            .foregroundColor(.red)
                    }
                    
                    TextField("Adverse reaction details", text: $reactionDetails, axis: .vertical)
                    
                    Picker(selection: $vaccine, label: Text("Vaccine administered")) {
                        ForEach(vaccines, id: \.self) { vaccine in
                            Text(vaccine)
                        }
                    }
                    
                    if vaccineBlank {
                        Text("Field blank")
                            .foregroundColor(.red)
                    }
                    
                    DatePicker("Vaccine Date", selection: $vaccDate, in: ...maximumDate, displayedComponents: .date)
                    
                }
                
                Section(header: Text("Vaccinator")) {
                    TextField("First Name", text: $vaccinatorFirstname)
                        .autocapitalization(.words)
                        .textContentType(.givenName)
                        .disableAutocorrection(true)
                        .onReceive(Just(vaccinatorFirstname)) { newValue in
                            let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                            if filtered != newValue {
                                self.vaccinatorFirstname = filtered
                                //self.showingAlert = true
                            } else if newValue.count < 3 && newValue.count != 0 {
                                self.fnameShort = true
                                //self.employeeID = String(newValue.prefix(8))
                                //self.showingAlert = true
                            } else if newValue.count >= 3 {
                                self.fnameShort = false
                            }
                        }
                    
                    if fnameShort {
                        Text("Name too short")
                            .foregroundColor(.red)
                    }
                    
                    if fnameBlank {
                        Text("Field blank")
                            .foregroundColor(.red)
                    }
                    
                    TextField("Last Name", text: $vaccinatorSurname)
                        .autocapitalization(.words)
                        .textContentType(.familyName)
                        .disableAutocorrection(true)
                        .onReceive(Just(vaccinatorSurname)) { newValue in
                            let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                            if filtered != newValue {
                                self.vaccinatorSurname = filtered
                                //self.showingAlert = true
                            } else if newValue.count < 3 && newValue.count != 0 {
                                self.lnameShort = true
                                //self.employeeID = String(newValue.prefix(8))
                                //self.showingAlert = true
                            } else if newValue.count >= 3 {
                                self.lnameShort = false
                            }
                        }
                    
                    if lnameShort {
                        Text("Name too short")
                            .foregroundColor(.red)
                    }
                    
                    if lnameBlank {
                        Text("Field blank")
                            .foregroundColor(.red)
                    }
                    
                    TextField("Job Title/Role", text: $vaccinatorjobrole)
                        .autocapitalization(.words)
                        .textContentType(.givenName)
                        .disableAutocorrection(true)
                        .onReceive(Just(vaccinatorjobrole)) { newValue in
                            self.jobroleBlank = false
                            let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                            if filtered != newValue {
                                self.vaccinatorjobrole = filtered
                                //self.showingAlert = true
                            } else if newValue.count > 100 {
                                self.vaccinatorjobrole = String(newValue.prefix(100))
                            } else if newValue.count < 3 && newValue.count != 0 {
                                self.jobroleShort = true
                            } else if newValue.count >= 3 {
                                self.jobroleShort = false
                            }
                        }
                }
                    
                
            }
            
            Button(action: {
                if !self.isChecked {
                    self.consented = false
                    self.showingAlert = true
                    return
                }else if String(self.administered)  == "Unselected" {
                    self.administeredBlank = true
                    self.showingAlert = true
                }else if String(self.vaccine)  == "Unselected" {
                    self.vaccineBlank = true
                    self.showingAlert = true
                }else if vaccinatorjobrole.isEmpty || self.jobroleShort{
                    self.jobroleBlank = true
                    self.showingAlert = true
                }else if vaccinatorFirstname.isEmpty || self.fnameShort {
                    self.fnameBlank = true
                    self.showingAlert = true
                }else if vaccinatorSurname.isEmpty || self.lnameShort{
                    self.lnameBlank = true
                    self.showingAlert = true
                }
                
                if self.showingAlert { return }
                
                data.administeredonbody = self.administered
                data.vaccineadministered = self.vaccine
                data.adversereaction = self.reactionDetails
                data.vaccinedate = self.vaccDate
                data.vaccinatorfname = self.vaccinatorFirstname
                data.vaccinatorlname = self.vaccinatorSurname
                data.vaccinatorjob = self.vaccinatorjobrole
                self.isActive = true
                
                

                
            }) {
                Text("Submit")
                    .fontWeight(.bold)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .cornerRadius(10.0)
            }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Unfilled Fields"), message: Text("Please check and fill all fields"), dismissButton: .default(Text("OK")))
            }
            

        }
        
        NavigationLink(
            destination: Upload(),
            isActive: $isActive,
            label: {
                //Text("Go to Detail View")
            })


    }
    

}


struct ManualorSearch: View {
    @State private var isActive = false
    @State private var isActive1 = false
    
    var body: some View {
        Form{
            
            Text("would you like to enter the data manually or search for the employee data?")
            
            Button(action: {
                if true{
                    self.isActive = true
                }
            }) {
                Text("Manual")
                    .fontWeight(.bold)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .cornerRadius(10.0)
            }
            
            Button(action: {
                if true{
                    self.isActive1 = true
                }
            }) {
                Text("Search")
                    .fontWeight(.bold)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .cornerRadius(10.0)
            }
            
            

        }
        
        NavigationLink(
            destination: EmployeeSearch(),
            isActive: $isActive1,
            label: {
                //Text("Go to Detail View")
            })
        
        NavigationLink(
            destination: UserForm(),
            isActive: $isActive,
            label: {
                //Text("Go to Detail View")
            })
        

    }
    
}

struct EmployeeSearch: View {
    @State private var firstName = ""
    @State private var fnameBlank = false
    @State private var fnameShort = false
    @State private var lastName = ""
    @State private var lnameBlank = false
    @State private var lnameShort = false
    @State private var employeeID = ""
    @State private var smartCardNumber = ""
    @State private var nhsNumber = ""
    @State private var isActive = false
    @State private var showingAlert = false
    @State private var employeeidShort = false
    @State private var smartcardShort = false
    @State private var nhsnumShort = false
    @State private var search = ""
    @State private var searchcat = ""
    
    
    var body: some View {
        Form{
            
            
            Section(header: Text("Name")) {
                TextField("First Name", text: $firstName)
                    .autocapitalization(.words)
                    .textContentType(.givenName)
                    .disableAutocorrection(true)
                    .onReceive(Just(firstName)) { newValue in
                        let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                        if filtered != newValue {
                            self.firstName = filtered
                            //self.showingAlert = true
                        } else if newValue.count < 3 && newValue.count != 0 {
                            self.fnameShort = true
                            //self.employeeID = String(newValue.prefix(8))
                            //self.showingAlert = true
                        } else if newValue.count >= 3 {
                            self.fnameShort = false
                        }
                    }
                
                if fnameShort {
                    Text("Name too short")
                        .foregroundColor(.red)
                }
                
                if fnameBlank {
                    Text("Field blank")
                        .foregroundColor(.red)
                }
                
                TextField("Last Name", text: $lastName)
                    .autocapitalization(.words)
                    .textContentType(.familyName)
                    .disableAutocorrection(true)
                    .onReceive(Just(lastName)) { newValue in
                        let filtered = newValue.filter { "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ".contains($0) }
                        if filtered != newValue {
                            self.lastName = filtered
                            //self.showingAlert = true
                        } else if newValue.count < 3 && newValue.count != 0 {
                            self.lnameShort = true
                            //self.employeeID = String(newValue.prefix(8))
                            //self.showingAlert = true
                        } else if newValue.count >= 3 {
                            self.lnameShort = false
                        }
                    }
                
                if lnameShort {
                    Text("Name too short")
                        .foregroundColor(.red)
                }
                
                if lnameBlank {
                    Text("Field blank")
                        .foregroundColor(.red)
                }
            }
            
            Section(header: Text("Employee ID Number")) {
                TextField("Employee ID Number", text: $employeeID)
                    .keyboardType(.numberPad)
                    .onReceive(Just(employeeID)) { newValue in
                        let filtered = newValue.filter { "0123456789".contains($0) }
                        self.employeeidShort = false
                        if filtered != newValue {
                            self.employeeID = filtered
                            //self.showingAlert = true
                        } else if newValue.count > 8 {
                            self.employeeID = String(newValue.prefix(8))
                            //self.showingAlert = true
                        }else if newValue.count < 8 && newValue.count > 0 {
                            self.employeeidShort = true
                        }
                    }
                
                if employeeidShort {
                    Text("Field requires 8 characters")
                        .foregroundColor(.red)
                }
            }
            Section(header: Text("Smart Card Number")) {
                TextField("Smart Card Number", text: $smartCardNumber)
                    .keyboardType(.numberPad)
                    .onReceive(Just(smartCardNumber)) { newValue in
                        let filtered = newValue.filter { "0123456789".contains($0) }
                        self.smartcardShort = false
                        if filtered != newValue {
                            self.smartCardNumber = filtered
                            //self.showingAlert = true
                        } else if newValue.count > 12 {
                            self.smartCardNumber = String(newValue.prefix(12))
                            //self.showingAlert = true
                        } else if newValue.count < 12 && newValue.count > 0{
                            self.smartcardShort = true
                        }
                    }
                
                if smartcardShort {
                    Text("Field requires 12 characters")
                        .foregroundColor(.red)
                }
                
            }
            Section(header: Text("NHS Number")) {
                TextField("NHS Number", text: $nhsNumber)
                    .keyboardType(.numberPad)
                    .onReceive(Just(nhsNumber)) { newValue in
                        let filtered = newValue.filter { "0123456789".contains($0) }
                        self.nhsnumShort = false
                        if filtered != newValue {
                            self.nhsNumber = filtered
                            //self.showingAlert = true
                        } else if newValue.count > 10 {
                            self.nhsNumber = String(newValue.prefix(10))
                            //self.showingAlert = true
                        } else if newValue.count < 10 && newValue.count > 0 {
                            self.nhsnumShort = true
                        }
                    }
                
                if nhsnumShort {
                    Text("Field requires 10 characters")
                        .foregroundColor(.red)
                }
            }
            
            Button(action: {
                if (!self.firstName.isEmpty && !self.fnameShort && !self.lastName.isEmpty && !self.fnameShort) {
                    self.searchcat = "name"
                    self.search = self.firstName + self.lastName
                    self.isActive = true
                    fetchEmployeesSearch(search: self.searchcat+self.search)
                    return
                }else if !self.employeeID.isEmpty && !self.employeeidShort{
                    self.searchcat = "employeeid"
                    self.search = self.employeeID
                    self.isActive = true
                    fetchEmployeesSearch(search: self.searchcat+self.search)
                    return
                }else if !self.smartCardNumber.isEmpty && !self.smartcardShort{
                    self.searchcat = "smartcardnumber"
                    self.search = self.smartCardNumber
                    self.isActive = true
                    fetchEmployeesSearch(search: self.searchcat+self.search)
                    return
                }else if !self.nhsNumber.isEmpty && !self.nhsnumShort{
                    self.searchcat = "nhsnumber"
                    self.search = self.nhsNumber
                    self.isActive = true
                    fetchEmployeesSearch(search: self.searchcat+self.search)
                    return
                }
                self.showingAlert = true
                
            }) {
                Text("Submit")
                    .fontWeight(.bold)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .cornerRadius(10.0)
            }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Unfilled Fields"), message: Text("Please fill a field to search"), dismissButton: .default(Text("OK")))
            }
            

        }
        
        NavigationLink(
            destination: EmployeeList(),
            isActive: $isActive,
            label: {
                //Text("Go to Detail View")
            })
        

    }
    
}


struct CardView: View {
    let title: String
    let subtext: String
    let subtext1: String
    let subtext2: String
    @Binding var isActive: Bool
    
    var body: some View {
        Button(action: {
            print(self.title)
            data.employer = self.title
            isActive = true
            // Do something when button is tapped
        }) {
            VStack(alignment: .leading) {
                Text(self.title)
                    .font(.headline)
                
                Label("\(subtext2)", systemImage: "clock")
                HStack {
                    Label("\(subtext)", systemImage: "person.3")
                    Spacer()
                    Label("\(subtext1)", systemImage: "clock")
                        .padding(.trailing, 20)
                }
                .font(.caption)
            }
            .padding()
            .foregroundColor(.yellow)
        }

    }
}

struct EmployeeButton: View {
    let title: String
    let subtext: String
    @Binding var isActive: Bool
    
    var body: some View {
        Button(action: {
            print(self.title)
            data.employer = self.title
            isActive = true
            // Do something when button is tapped
        }) {
            Text(title)
                .padding()
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(40)
        }
    }
}

struct EmployeeList: View {
    @State private var buttonTitles: [[String]] = [["t1","t2", "t3","t4"]]
    @State private var isActive: Bool = false
    
    init(){
        self.buttonTitles = api.employees
        print(self.buttonTitles)
        print(self.buttonTitles[0])
        print(self.buttonTitles[0][0])
    }
    
    
    var body: some View {
        
        VStack {
            ForEach(buttonTitles, id: \.self) { title in
                CardView(title: title[0], subtext: title[1], subtext1: title[2], subtext2: title[3], isActive: $isActive )
            }
        }
        .onAppear {
            fetchButtonTitles()
            self.buttonTitles = api.employees
        }
        NavigationLink(
            destination: UserForm(),
            isActive: $isActive,
            label: {
                //Text("Go to Detail View")
            })
    }
    
    /*func setvar(){
        isActive = true
        print("move")
    }*/
    
    func fetchButtonTitles() {
        //self.buttonTitles = api.employees
    }
}

struct Upload: View {
    
    var body: some View {
        VStack{
            Text("uploaded data")
            
        }.onAppear {
            postData()
        }
    }
}

struct CheckboxToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            Image(systemName: configuration.isOn ? "checkmark.square" : "square")
                .foregroundColor(configuration.isOn ? .green : .primary)
            configuration.label
        }
    }
}

struct iOSCheckboxToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        // 1
        Button(action: {

            // 2
            configuration.isOn.toggle()

        }, label: {
            HStack {
                // 3
                Image(systemName: configuration.isOn ? "checkmark.square" : "square")

                configuration.label
            }
        })
    }
}
